# Arcoíris del Tesoro (mod para Minecraft Forge 1.20.1)

Durante el día aparecen arcoíris por el mapa. Donde termina cada uno hay un **cofre del tesoro** con recompensas muy especiales.

## Cómo conseguir el .jar con GitHub
1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`).
   Si la subida web no incluye `.github`, crea el archivo a mano con
   *Add file > Create new file* y el nombre `.github/workflows/build.yml`.
3. En la pestaña **Actions** se ejecuta solo "Compilar mod (.jar)" (unos minutos).
4. Al terminar en verde, descarga el artefacto **TreasureRainbow-jar**: dentro está `treasure_rainbow-1.5.0.jar`.
   Cópialo a la carpeta `mods` de Forge 1.20.1 (47.3.0 o superior). Ese mismo .jar se sube a CurseForge.

## Cómo funciona
- **Cuándo**: solo en el Overworld, de día y sin tormenta. Cada 20 segundos hay una pequeña probabilidad
  por jugador (6 %). **Justo después de que pare de llover sube al 40 %** durante unos 5 minutos.
- **Dónde**: en campo abierto, a 50-90 bloques del jugador, sobre suelo sólido y con cielo despejado.
  Nunca hay dos arcoíris a menos de 110 bloques.
- **El arcoíris**: un arco de 7 colores (rojo fuera, violeta dentro) de tamaño variable que aparece poco a poco.
  Se ve desde lejos. Un extremo acaba en el cofre.
- **Cuánto dura**: unos 12 minutos, hasta que anochezca o haya tormenta, o hasta unos 5 segundos después de que
  alguien abra el cofre. Si nadie lo abre, el cofre se esfuma con el arcoíris.
- **El cofre** brilla y suelta destellos de colores. Al abrirlo por primera vez estalla una celebración.
  Después se queda como un cofre normal que puedes romper y llevarte (se puede colocar como decoración).

## El tesoro
- **Siempre**: 1 Gema arcoíris (30 % de una segunda) y 3-8 Polvo de arcoíris.
- **Riquezas** (4-6 tiradas): diamantes, esmeraldas, oro, botellas de experiencia, manzanas doradas, perlas de ender,
  chatarra de netherita, lapislázuli, amatista, etiquetas, sillas...
- **Especiales** (1-2 tiradas): manzana dorada encantada, tótem de la inmortalidad, libro encantado de nivel alto
  (con encantamientos de tesoro como Reparación), lingotes de netherita, corazón del mar, pico y espada de diamante
  encantados, tridente encantado, elytras, estrella del Nether, discos Pigstep y Otherside.

## Objetos
- **Gema arcoíris**: clic derecho para consumirla. Da 7 efectos durante 3 minutos, uno por color:
  Fuerza (rojo), Resistencia al fuego (naranja), Suerte (amarillo), Regeneración (verde),
  Gracia del delfín (azul), Visión nocturna (añil) y Resistencia (violeta).
- **Polvo de arcoíris**: 1 lana blanca + 2 polvos = **Lana arcoíris** (bloque animado que cambia de color).
- **Cofre del arcoíris**: solo en creativo o recogiéndolo tras abrirlo.

## Probarlo sin esperar
Como operador, escribe `/rainbow`: crea un arcoíris con su cofre a unos 24-38 bloques de ti.
Ese arcoíris no desaparece al anochecer (solo por el tiempo, por la tormenta no, o al abrir el cofre).

## Ajustes rápidos
- `RainbowEvents.java`: `BASE_CHANCE`, `AFTER_RAIN_CHANCE`, `CHECK_INTERVAL`.
- `RainbowSpawner.java`: distancia de aparición y `MIN_SPACING`.
- `RainbowEntity.java`: `DEFAULT_LIFE` (duración).
- `data/treasure_rainbow/loot_tables/chests/rainbow_treasure.json`: el botín (pesos y cantidades).
- `RainbowRenderer.java`: colores, grosor y transparencia del arco.

## Novedades 1.1.0: San Patricio

- **Caldero de oro**: en cada arcoíris hay un 8 % de probabilidad (35 % en el Día de San Patricio) de que junto al cofre
  aparezca un **caldero de oro**, el duende **San Patricio** y un **cofre legendario**. El botín legendario mezcla cosas
  muy buenas de vanilla con objetos valiosos y objetos al azar **de todos los mods instalados**.
  Si nadie abre el cofre, el caldero se esfuma con el arcoíris. El duende se queda unos 20 minutos.
- **Trébol de cuatro hojas**: crece suelto por el Overworld (parches pequeños en suelo de hierba/tierra). Se recoge con un clic.
- **Comercio con San Patricio**: clic derecho sobre él y paga con tréboles: oro, esmeraldas, diamantes, poción de suerte,
  gemas arcoíris, tótem, manzana dorada encantada, libro de Reparación, netherita, élitros y **objetos misteriosos de otros mods**.
- **Día de San Patricio** (evento): al amanecer hay un 6 % de que empiece y dura hasta el siguiente amanecer.
  Efecto *Día de San Patricio*: **Suerte, respiración acuática e inmunidad al fuego** + **5 corazones extra de escudo**
  (no quitan vida normal). Si se gastan, **al comer se regeneran**. Al acabar el evento desaparecen los corazones y los efectos.
  Durante el evento hay más arcoíris, más duendes especiales y duendes paseando cerca de los jugadores.

### Comandos (operadores)
- `/rainbow leprechaun`: arcoíris con caldero, duende y cofre legendario.
- `/saintpatrick start` y `/saintpatrick stop`: empezar o terminar el evento.
- Huevo de generación del duende en la pestaña creativa.

### Ajustes rápidos nuevos
- `SaintPatrickDay.java`: `START_CHANCE`, `SHIELD`.
- `RainbowSpawner.java`: `LEPRECHAUN_CHANCE`, `LEPRECHAUN_CHANCE_EVENT`, `LEPRECHAUN_STAY`.
- `LeprechaunEntity.java`: lista de trueques (`updateTrades`).
- `data/treasure_rainbow/worldgen/placed_feature/four_leaf_clover_patch.json`: `chance` = rareza de los tréboles.

## Novedades 1.2.0: Noche de San Juan (solsticio de verano)

Se celebra **cada 2 días del mundo** (el día 2, 4, 6...), **al caer la noche, hasta el amanecer**.

- **Hogueras de San Juan**: aparecen por el mundo (cerca de los jugadores, con cohetes) y se apagan al amanecer.
  También puedes fabricarte una permanente: campfire + 3 hierbas de San Juan.
- **Saltar el fuego**: se pueden cruzar sin hacer daño; purifican (quitan efectos negativos y el fuego).
  Cerca de una hoguera los jugadores se curan poco a poco y los **no-muertos se queman** (culto solar).
- **Rituales** (clic derecho en la hoguera): **hierba de San Juan** = purificación de todos los cercanos + Regeneración
  (y Fuerza si es la Noche de San Juan). **Papel** = deseo que se quema (solo esa noche): experiencia + Suerte,
  tréboles de cuatro hojas o un objeto valioso de cualquier mod.
- **Fertilidad**: durante la noche crecen solos los cultivos y árboles jóvenes cerca de los jugadores y los animales entran en celo.
- **Bendición del Solsticio**: efecto de la noche (salto aumentado para saltar las hogueras).
- **Hierba de San Juan**: flor amarilla que crece por el Overworld. **Coca de San Juan**: trigo x3 + azúcar + huevo + bayas dulces (da 2).
- Comandos de operador: `/sanjuan start` y `/sanjuan stop`.
- Ajustes: `SaintJohnNight.java` (`INTERVAL_DAYS` = 5, `NIGHTFALL`, `BONFIRE_CHANCE`), `SanJuanBonfireBlock.java` (rituales y recompensas).

### Mejoras 1.3.0 (San Juan)
- **Ahora ocurre cada 2 días.**
- **Tres saltos**: saltar la misma hoguera (o varias) 3 veces la Noche de San Juan da Suerte II, Fuerza y experiencia.
- **Agua de San Juan**: con una botella de cristal en la hoguera (solo esa noche). Al beberla purifica, cura y da Regeneración.

## Novedades 1.4.0

### El Pájaro Loco (Noche de San Juan)
Pájaro de correfoc gigante (plumas tipo escamas, cresta roja, cuerno gris, pico que escupe chispas). Aparece suelto
la Noche de San Juan y se va al amanecer. Se ilumina a sí mismo: brilla, se dibuja a plena luz y lanza **cohetes
amarillos** que suben al cielo y explotan. No ataca. Suelta plumas, pólvora y cohetes. Huevo en la pestaña creativa.

### Navidad (evento)
Empieza de golpe al amanecer (10 %; segura del 24 al 26 de diciembre reales) y dura hasta el siguiente amanecer.
- **Nieva en todo el mundo, sea cual sea el bioma**: nieve mágica en el suelo (se derrite sola al acabar) y copos que caen por la pantalla.
- **Elfos** que aparecen de golpe; hablar con uno da un **regalo** (una vez). Se van al acabar.
- **Trineo mágico** con renos que cruza el cielo y va soltando **regalos mágicos**.
- **Regalo**: clic derecho para abrirlo. Da 5-8 objetos variados, 2-4 objetos **al azar de los mods instalados** y 1-2 objetos valiosos.
- Comandos: `/christmas start`, `/christmas stop`, `/christmas sleigh`.

### San Valentín (evento)
Empieza al amanecer (8 %; seguro el 14 de febrero real) y dura hasta el siguiente amanecer.
- **Cupido**, un mini bebé alado con arco, vuela por el mundo y lanza **flechas de corazón que curan** (sin hacer daño).
- Al derrotarlo puede soltar el **Halo Angelical** (30 %, más con Looting).
- Comandos: `/valentine start`, `/valentine stop`.

### Halo Angelical
- **+5 corazones extra**, **respirar bajo el agua**, **niega el daño de caída**, y **envenena y debilita automáticamente** a quien te ataque.
- Se equipa en un **hueco nuevo encima del casco** (casilla sobre el hueco del casco en el inventario: clic con el halo en el cursor)
  o con **clic derecho** sobre el objeto. Se ve flotando sobre la cabeza. Se suelta al morir (salvo keepInventory).

## Novedades 1.5.0

### San Juan, cada 2 días y con el suelo lleno de fuegos artificiales
La Noche de San Juan se celebra ahora **cada 2 días**. Durante la noche el suelo alrededor de los jugadores
se llena de **surtidores de chispas y cohetes de colores** que salen de la tierra y explotan en el cielo.

### Busójárás (Mohács, Hungría)
Carnaval en el que los busós (máscaras de madera con cuernos, pieles de oveja y cencerros) espantan al invierno y a
los malos espíritus. Evento al amanecer (8 %), dura hasta el siguiente amanecer.
- **Busó** (mob): máscara de madera con cuernos, piel de oveja, cencerro. **Te persigue y te empuja** haciendo ruido
  (sin hacer daño) y **espanta a los monstruos**. Suelta lana, farsangi fánk, a veces la máscara y rara vez una campana.
- **Máscara de Busó**: se lleva en la cabeza (clic derecho para ponértela). Los busós te toman por uno de los suyos
  y los monstruos cercanos huyen de ti (también fuera del evento).
- **Farsangi fánk**: el buñuelo de carnaval (2 trigo + azúcar + huevo + botella de miel = 4).
- **Despedir al invierno**: durante el Busójárás, clic derecho en una hoguera con una **bola de nieve** la quema:
  da polvo de hueso, flores, experiencia y Regeneración.
- Comandos: `/busojaras start`, `/busojaras stop`.
