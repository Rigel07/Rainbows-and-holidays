package com.treasurerainbow.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * Efecto "Día de San Patricio". Es la marca visible del evento (icono verde y dorado);
 * la suerte, la respiración acuática, la inmunidad al fuego y el escudo de corazones
 * los gestiona {@code SaintPatrickDay} mientras dura el evento.
 */
public class SaintPatrickEffect extends MobEffect {
    public SaintPatrickEffect() {
        super(MobEffectCategory.BENEFICIAL, 0x2ECC40);
    }
}
