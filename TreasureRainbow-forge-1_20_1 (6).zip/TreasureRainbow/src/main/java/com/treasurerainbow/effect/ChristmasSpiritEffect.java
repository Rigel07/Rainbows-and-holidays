package com.treasurerainbow.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Marca de la Navidad: mientras la tienes, el cliente hace nevar a tu alrededor en cualquier bioma. */
public class ChristmasSpiritEffect extends MobEffect {
    public ChristmasSpiritEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xBFE8FF);
    }
}
