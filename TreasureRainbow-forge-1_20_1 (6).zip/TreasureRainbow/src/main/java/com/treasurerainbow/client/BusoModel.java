package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: BusoModel. */
public class BusoModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "buso"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart skirt;
    private final ModelPart head;
    private final ModelPart mask;
    private final ModelPart horn_r;
    private final ModelPart horn_l;
    private final ModelPart cap;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;
    private final ModelPart bell;

    public BusoModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.skirt = root.getChild("skirt");
        this.head = root.getChild("head");
        this.mask = root.getChild("head").getChild("mask");
        this.horn_r = root.getChild("head").getChild("horn_r");
        this.horn_l = root.getChild("head").getChild("horn_l");
        this.cap = root.getChild("head").getChild("cap");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
        this.bell = root.getChild("bell");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-5F, 0F, -3F, 10F, 12F, 6F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt = root.addOrReplaceChild("skirt", CubeListBuilder.create().texOffs(32, 16).addBox(-6F, 0F, -4F, 12F, 5F, 8F), PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_mask = p_head.addOrReplaceChild("mask", CubeListBuilder.create().texOffs(32, 0).addBox(-4.5F, -9F, -6F, 9F, 10F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create().texOffs(54, 0).addBox(-1F, -7F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(-4.5F, -7F, -4F, 0F, 0F, -0.5F));
        PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create().texOffs(54, 0).addBox(-1F, -7F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(4.5F, -7F, -4F, 0F, 0F, 0.5F));
        PartDefinition p_cap = p_head.addOrReplaceChild("cap", CubeListBuilder.create().texOffs(62, 0).addBox(-5F, -10.5F, -5F, 10F, 3F, 10F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(72, 16).addBox(-3F, -2F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(-7F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(72, 16).addBox(-1F, -2F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(7F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(88, 16).addBox(-2F, 0F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(-2.5F, 12F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(88, 16).addBox(-2F, 0F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(2.5F, 12F, 0F, 0F, 0F, 0F));
        PartDefinition p_bell = root.addOrReplaceChild("bell", CubeListBuilder.create().texOffs(104, 16).addBox(-1.5F, 0F, -1.5F, 3F, 3F, 3F), PartPose.offsetAndRotation(0F, 10F, -5F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        float swing = limbSwing * 0.6662F;
        this.leg_r.xRot = Mth.cos(swing) * 1.4F * limbSwingAmount;
        this.leg_l.xRot = Mth.cos(swing + Mth.PI) * 1.4F * limbSwingAmount;
        this.arm_r.xRot = Mth.cos(swing + Mth.PI) * 1.2F * limbSwingAmount;
        this.arm_l.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        this.arm_r.zRot = 0.08F + Mth.cos(ageInTicks * 0.09F) * 0.05F;
        this.arm_l.zRot = -0.08F - Mth.cos(ageInTicks * 0.09F) * 0.05F;
        this.bell.xRot = Mth.sin(swing) * 0.4F * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
