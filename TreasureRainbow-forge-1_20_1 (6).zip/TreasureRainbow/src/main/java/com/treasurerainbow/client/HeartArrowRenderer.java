package com.treasurerainbow.client;

import com.treasurerainbow.entity.HeartArrowEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class HeartArrowRenderer extends ArrowRenderer<HeartArrowEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("textures/entity/projectiles/arrow.png");

    public HeartArrowRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(HeartArrowEntity entity) {
        return TEXTURE;
    }
}
