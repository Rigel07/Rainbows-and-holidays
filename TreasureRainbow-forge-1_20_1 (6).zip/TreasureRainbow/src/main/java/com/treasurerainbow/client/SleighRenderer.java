package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.SleighEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** El trineo mágico se dibuja siempre a plena luz (se ve de lejos en el cielo). */
public class SleighRenderer extends EntityRenderer<SleighEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/sleigh.png");
    private final SleighModel<SleighEntity> model;

    public SleighRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new SleighModel<>(context.bakeLayer(SleighModel.LAYER));
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(SleighEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0D, -1.501D, 0.0D);
        this.model.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTick, 0.0F, 0.0F);
        VertexConsumer consumer = buffer.getBuffer(this.model.renderType(TEXTURE));
        this.model.renderToBuffer(poseStack, consumer, 15728880, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(SleighEntity entity) {
        return TEXTURE;
    }
}
