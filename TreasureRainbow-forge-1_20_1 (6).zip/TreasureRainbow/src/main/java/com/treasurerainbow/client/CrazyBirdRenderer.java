package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.CrazyBirdEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** El Pájaro Loco se dibuja siempre a plena luz: se ilumina a sí mismo. */
public class CrazyBirdRenderer extends MobRenderer<CrazyBirdEntity, CrazyBirdModel<CrazyBirdEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/pajaro_loco.png");

    public CrazyBirdRenderer(EntityRendererProvider.Context context) {
        super(context, new CrazyBirdModel<>(context.bakeLayer(CrazyBirdModel.LAYER)), 1.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(CrazyBirdEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(CrazyBirdEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.5F, 1.5F, 1.5F);
    }

    @Override
    protected int getBlockLightLevel(CrazyBirdEntity entity, BlockPos pos) {
        return 15;
    }
}
