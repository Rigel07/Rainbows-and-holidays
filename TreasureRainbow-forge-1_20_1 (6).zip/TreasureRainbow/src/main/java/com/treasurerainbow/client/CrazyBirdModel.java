package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: CrazyBirdModel. */
public class CrazyBirdModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "pajaro_loco"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart neck;
    private final ModelPart head;
    private final ModelPart beak_up;
    private final ModelPart beak_low;
    private final ModelPart comb;
    private final ModelPart horn;
    private final ModelPart tail_a;
    private final ModelPart tail_b;
    private final ModelPart tail_c;
    private final ModelPart wing_r;
    private final ModelPart wing_l;
    private final ModelPart leg_r;
    private final ModelPart foot_r;
    private final ModelPart leg_l;
    private final ModelPart foot_l;

    public CrazyBirdModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.neck = root.getChild("neck");
        this.head = root.getChild("neck").getChild("head");
        this.beak_up = root.getChild("neck").getChild("head").getChild("beak_up");
        this.beak_low = root.getChild("neck").getChild("head").getChild("beak_low");
        this.comb = root.getChild("neck").getChild("head").getChild("comb");
        this.horn = root.getChild("neck").getChild("head").getChild("horn");
        this.tail_a = root.getChild("tail_a");
        this.tail_b = root.getChild("tail_b");
        this.tail_c = root.getChild("tail_c");
        this.wing_r = root.getChild("wing_r");
        this.wing_l = root.getChild("wing_l");
        this.leg_r = root.getChild("leg_r");
        this.foot_r = root.getChild("leg_r").getChild("foot_r");
        this.leg_l = root.getChild("leg_l");
        this.foot_l = root.getChild("leg_l").getChild("foot_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5F, -5F, -6F, 10F, 10F, 12F), PartPose.offsetAndRotation(0F, 13F, 0F, 0F, 0F, 0F));
        PartDefinition p_neck = root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(44, 0).addBox(-3F, -9F, -3F, 6F, 9F, 6F), PartPose.offsetAndRotation(0F, 9F, -4F, 0F, 0F, 0F));
        PartDefinition p_head = p_neck.addOrReplaceChild("head", CubeListBuilder.create().texOffs(68, 0).addBox(-3.5F, -6F, -3.5F, 7F, 6F, 7F), PartPose.offsetAndRotation(0F, -9F, -1F, 0F, 0F, 0F));
        PartDefinition p_beak_up = p_head.addOrReplaceChild("beak_up", CubeListBuilder.create().texOffs(96, 0).addBox(-2F, -3.5F, -8.5F, 4F, 3F, 5F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_beak_low = p_head.addOrReplaceChild("beak_low", CubeListBuilder.create().texOffs(114, 0).addBox(-1.5F, 0F, -4F, 3F, 2F, 4F), PartPose.offsetAndRotation(0F, -0.5F, -3.5F, 0.25F, 0F, 0F));
        PartDefinition p_comb = p_head.addOrReplaceChild("comb", CubeListBuilder.create().texOffs(0, 22).addBox(-1F, -3F, -3F, 2F, 3F, 6F), PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_horn = p_head.addOrReplaceChild("horn", CubeListBuilder.create().texOffs(16, 22).addBox(-1F, -5F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(2F, -6F, 0.5F, 0F, 0F, 0.3F));
        PartDefinition p_tail_a = root.addOrReplaceChild("tail_a", CubeListBuilder.create().texOffs(24, 22).addBox(-1.5F, -1F, 0F, 3F, 2F, 10F), PartPose.offsetAndRotation(0F, 11F, 6F, -0.35F, 0F, 0F));
        PartDefinition p_tail_b = root.addOrReplaceChild("tail_b", CubeListBuilder.create().texOffs(24, 22).addBox(-1.5F, -1F, 0F, 3F, 2F, 10F), PartPose.offsetAndRotation(-3F, 11F, 5.5F, -0.2F, 0.45F, 0F));
        PartDefinition p_tail_c = root.addOrReplaceChild("tail_c", CubeListBuilder.create().texOffs(24, 22).addBox(-1.5F, -1F, 0F, 3F, 2F, 10F), PartPose.offsetAndRotation(3F, 11F, 5.5F, -0.2F, -0.45F, 0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(50, 22).addBox(-1F, 0F, -5F, 2F, 8F, 10F), PartPose.offsetAndRotation(-5.5F, 9F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(50, 22).addBox(-1F, 0F, -5F, 2F, 8F, 10F), PartPose.offsetAndRotation(5.5F, 9F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(74, 22).addBox(-1.5F, 0F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(-3F, 17F, 1F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_leg_r.addOrReplaceChild("foot_r", CubeListBuilder.create().texOffs(86, 22).addBox(-2.5F, -1F, -4F, 5F, 1F, 5F), PartPose.offsetAndRotation(0F, 7F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(74, 22).addBox(-1.5F, 0F, -1.5F, 3F, 7F, 3F), PartPose.offsetAndRotation(3F, 17F, 1F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_leg_l.addOrReplaceChild("foot_l", CubeListBuilder.create().texOffs(86, 22).addBox(-2.5F, -1F, -4F, 5F, 1F, 5F), PartPose.offsetAndRotation(0F, 7F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float walk = limbSwing * 0.9F;
        this.leg_r.xRot = Mth.cos(walk) * 1.2F * limbSwingAmount;
        this.leg_l.xRot = Mth.cos(walk + Mth.PI) * 1.2F * limbSwingAmount;
        float flap = ageInTicks * 0.9F;
        float amount = 0.4F + limbSwingAmount;
        this.wing_r.zRot = 0.15F + Mth.sin(flap) * 0.14F * amount;
        this.wing_l.zRot = -0.15F - Mth.sin(flap) * 0.14F * amount;
        this.neck.xRot = Mth.sin(ageInTicks * 0.15F) * 0.08F + limbSwingAmount * 0.2F;
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.beak_low.xRot = 0.3F + Mth.sin(ageInTicks * 0.8F) * 0.12F;
        this.tail_a.yRot = Mth.sin(ageInTicks * 0.2F) * 0.15F;
        this.body.zRot = Mth.sin(walk) * 0.06F * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
