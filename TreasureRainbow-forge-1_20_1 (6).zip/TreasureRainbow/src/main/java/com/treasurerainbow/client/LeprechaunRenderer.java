package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.LeprechaunEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LeprechaunRenderer extends MobRenderer<LeprechaunEntity, LeprechaunModel<LeprechaunEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "textures/entity/leprechaun.png");

    public LeprechaunRenderer(EntityRendererProvider.Context context) {
        super(context, new LeprechaunModel<>(context.bakeLayer(LeprechaunModel.LAYER)), 0.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(LeprechaunEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(LeprechaunEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.8F, 0.8F, 0.8F);
    }
}
