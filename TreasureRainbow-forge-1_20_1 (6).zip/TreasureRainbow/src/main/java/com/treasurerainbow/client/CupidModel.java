package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: CupidModel. */
public class CupidModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "cupid"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart diaper;
    private final ModelPart head;
    private final ModelPart hair;
    private final ModelPart arm_r;
    private final ModelPart arm_l;
    private final ModelPart leg_r;
    private final ModelPart leg_l;
    private final ModelPart wing_r;
    private final ModelPart wing_l;
    private final ModelPart bow_mid;
    private final ModelPart bow_top;
    private final ModelPart bow_bot;

    public CupidModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.diaper = root.getChild("diaper");
        this.head = root.getChild("head");
        this.hair = root.getChild("head").getChild("hair");
        this.arm_r = root.getChild("arm_r");
        this.arm_l = root.getChild("arm_l");
        this.leg_r = root.getChild("leg_r");
        this.leg_l = root.getChild("leg_l");
        this.wing_r = root.getChild("wing_r");
        this.wing_l = root.getChild("wing_l");
        this.bow_mid = root.getChild("arm_r").getChild("bow_mid");
        this.bow_top = root.getChild("arm_r").getChild("bow_top");
        this.bow_bot = root.getChild("arm_r").getChild("bow_bot");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-3F, 0F, -2F, 6F, 6F, 4F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition p_diaper = root.addOrReplaceChild("diaper", CubeListBuilder.create().texOffs(20, 16).addBox(-3.5F, 0F, -2.5F, 7F, 2F, 5F), PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition p_hair = p_head.addOrReplaceChild("hair", CubeListBuilder.create().texOffs(32, 0).addBox(-4F, -9.5F, -4F, 8F, 2F, 8F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(44, 16).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(-4F, 14.5F, 0F, -1.4F, 0F, 0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(44, 16).addBox(-1F, 0F, -1F, 2F, 5F, 2F), PartPose.offsetAndRotation(4F, 14.5F, 0F, -1.0F, 0.4F, 0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(52, 16).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(-1.5F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(52, 16).addBox(-1F, 0F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(1.5F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(0, 26).addBox(-0.5F, -5F, 0F, 1F, 9F, 6F), PartPose.offsetAndRotation(-2F, 17F, 2F, 0F, 0.7F, 0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(0, 26).addBox(-0.5F, -5F, 0F, 1F, 9F, 6F), PartPose.offsetAndRotation(2F, 17F, 2F, 0F, -0.7F, 0F));
        PartDefinition p_bow_mid = p_arm_r.addOrReplaceChild("bow_mid", CubeListBuilder.create().texOffs(14, 26).addBox(-0.5F, 1F, -5F, 1F, 8F, 1F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_bow_top = p_arm_r.addOrReplaceChild("bow_top", CubeListBuilder.create().texOffs(18, 26).addBox(-0.5F, -1.5F, -5.5F, 1F, 2F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_bow_bot = p_arm_r.addOrReplaceChild("bow_bot", CubeListBuilder.create().texOffs(18, 26).addBox(-0.5F, 8.5F, -5.5F, 1F, 2F, 2F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        float flap = Mth.sin(ageInTicks * 0.9F) * 0.5F;
        this.wing_r.yRot = 0.7F + flap;
        this.wing_l.yRot = -0.7F - flap;
        this.arm_r.xRot = -1.4F + Mth.sin(ageInTicks * 0.1F) * 0.05F;
        this.arm_l.xRot = -1.0F;
        this.leg_r.xRot = Mth.sin(ageInTicks * 0.2F) * 0.2F;
        this.leg_l.xRot = -Mth.sin(ageInTicks * 0.2F) * 0.2F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
