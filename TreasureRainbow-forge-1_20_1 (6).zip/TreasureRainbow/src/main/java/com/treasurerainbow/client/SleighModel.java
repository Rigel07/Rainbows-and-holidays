package com.treasurerainbow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo generado: SleighModel. */
public class SleighModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TreasureRainbowMod.MOD_ID, "sleigh"), "main");

    private final ModelPart root;
    private final ModelPart runner_r;
    private final ModelPart runner_l;
    private final ModelPart base;
    private final ModelPart side_r;
    private final ModelPart side_l;
    private final ModelPart back;
    private final ModelPart front;
    private final ModelPart sack;
    private final ModelPart gift1;
    private final ModelPart gift2;
    private final ModelPart rod_r;
    private final ModelPart rod_l;
    private final ModelPart a_body;
    private final ModelPart a_neck;
    private final ModelPart a_head;
    private final ModelPart a_antler_r;
    private final ModelPart a_antler_l;
    private final ModelPart a_nose;
    private final ModelPart a_leg_fl;
    private final ModelPart a_leg_fr;
    private final ModelPart a_leg_bl;
    private final ModelPart a_leg_br;
    private final ModelPart b_body;
    private final ModelPart b_neck;
    private final ModelPart b_head;
    private final ModelPart b_antler_r;
    private final ModelPart b_antler_l;
    private final ModelPart b_nose;
    private final ModelPart b_leg_fl;
    private final ModelPart b_leg_fr;
    private final ModelPart b_leg_bl;
    private final ModelPart b_leg_br;

    public SleighModel(ModelPart root) {
        this.root = root;
        this.runner_r = root.getChild("runner_r");
        this.runner_l = root.getChild("runner_l");
        this.base = root.getChild("base");
        this.side_r = root.getChild("side_r");
        this.side_l = root.getChild("side_l");
        this.back = root.getChild("back");
        this.front = root.getChild("front");
        this.sack = root.getChild("sack");
        this.gift1 = root.getChild("gift1");
        this.gift2 = root.getChild("gift2");
        this.rod_r = root.getChild("rod_r");
        this.rod_l = root.getChild("rod_l");
        this.a_body = root.getChild("a_body");
        this.a_neck = root.getChild("a_neck");
        this.a_head = root.getChild("a_neck").getChild("a_head");
        this.a_antler_r = root.getChild("a_neck").getChild("a_head").getChild("a_antler_r");
        this.a_antler_l = root.getChild("a_neck").getChild("a_head").getChild("a_antler_l");
        this.a_nose = root.getChild("a_neck").getChild("a_head").getChild("a_nose");
        this.a_leg_fl = root.getChild("a_leg_fl");
        this.a_leg_fr = root.getChild("a_leg_fr");
        this.a_leg_bl = root.getChild("a_leg_bl");
        this.a_leg_br = root.getChild("a_leg_br");
        this.b_body = root.getChild("b_body");
        this.b_neck = root.getChild("b_neck");
        this.b_head = root.getChild("b_neck").getChild("b_head");
        this.b_antler_r = root.getChild("b_neck").getChild("b_head").getChild("b_antler_r");
        this.b_antler_l = root.getChild("b_neck").getChild("b_head").getChild("b_antler_l");
        this.b_nose = root.getChild("b_neck").getChild("b_head").getChild("b_nose");
        this.b_leg_fl = root.getChild("b_leg_fl");
        this.b_leg_fr = root.getChild("b_leg_fr");
        this.b_leg_bl = root.getChild("b_leg_bl");
        this.b_leg_br = root.getChild("b_leg_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_runner_r = root.addOrReplaceChild("runner_r", CubeListBuilder.create().texOffs(0, 0).addBox(-1F, 0F, -11F, 2F, 2F, 22F), PartPose.offsetAndRotation(-7F, 22F, 10F, 0F, 0F, 0F));
        PartDefinition p_runner_l = root.addOrReplaceChild("runner_l", CubeListBuilder.create().texOffs(0, 0).addBox(-1F, 0F, -11F, 2F, 2F, 22F), PartPose.offsetAndRotation(7F, 22F, 10F, 0F, 0F, 0F));
        PartDefinition p_base = root.addOrReplaceChild("base", CubeListBuilder.create().texOffs(48, 0).addBox(-8F, 0F, -10F, 16F, 4F, 20F), PartPose.offsetAndRotation(0F, 18F, 10F, 0F, 0F, 0F));
        PartDefinition p_side_r = root.addOrReplaceChild("side_r", CubeListBuilder.create().texOffs(0, 24).addBox(0F, -5F, -10F, 2F, 5F, 20F), PartPose.offsetAndRotation(-8F, 18F, 10F, 0F, 0F, 0F));
        PartDefinition p_side_l = root.addOrReplaceChild("side_l", CubeListBuilder.create().texOffs(0, 24).addBox(0F, -5F, -10F, 2F, 5F, 20F), PartPose.offsetAndRotation(6F, 18F, 10F, 0F, 0F, 0F));
        PartDefinition p_back = root.addOrReplaceChild("back", CubeListBuilder.create().texOffs(44, 24).addBox(-8F, -9F, 0F, 16F, 9F, 3F), PartPose.offsetAndRotation(0F, 18F, 17F, 0F, 0F, 0F));
        PartDefinition p_front = root.addOrReplaceChild("front", CubeListBuilder.create().texOffs(82, 24).addBox(-8F, -6F, 0F, 16F, 6F, 2F), PartPose.offsetAndRotation(0F, 18F, 0F, -0.3F, 0F, 0F));
        PartDefinition p_sack = root.addOrReplaceChild("sack", CubeListBuilder.create().texOffs(0, 49).addBox(-5F, -8F, 0F, 10F, 8F, 8F), PartPose.offsetAndRotation(0F, 18F, 6F, 0F, 0F, 0F));
        PartDefinition p_gift1 = root.addOrReplaceChild("gift1", CubeListBuilder.create().texOffs(36, 49).addBox(-2F, -4F, -2F, 4F, 4F, 4F), PartPose.offsetAndRotation(-2F, 10F, 8F, 0F, 0.4F, 0F));
        PartDefinition p_gift2 = root.addOrReplaceChild("gift2", CubeListBuilder.create().texOffs(36, 49).addBox(-2F, -4F, -2F, 4F, 4F, 4F), PartPose.offsetAndRotation(3F, 10F, 10F, 0F, -0.3F, 0F));
        PartDefinition p_rod_r = root.addOrReplaceChild("rod_r", CubeListBuilder.create().texOffs(52, 49).addBox(-0.5F, -0.5F, -16F, 1F, 1F, 16F), PartPose.offsetAndRotation(-3F, 19F, 0F, 0F, 0F, 0F));
        PartDefinition p_rod_l = root.addOrReplaceChild("rod_l", CubeListBuilder.create().texOffs(52, 49).addBox(-0.5F, -0.5F, -16F, 1F, 1F, 16F), PartPose.offsetAndRotation(3F, 19F, 0F, 0F, 0F, 0F));
        PartDefinition p_a_body = root.addOrReplaceChild("a_body", CubeListBuilder.create().texOffs(86, 49).addBox(-3F, -3F, -6F, 6F, 6F, 12F), PartPose.offsetAndRotation(0F, 14F, -16F, 0F, 0F, 0F));
        PartDefinition p_a_neck = root.addOrReplaceChild("a_neck", CubeListBuilder.create().texOffs(0, 67).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(0F, 12F, -22F, -0.5F, 0F, 0F));
        PartDefinition p_a_head = p_a_neck.addOrReplaceChild("a_head", CubeListBuilder.create().texOffs(12, 67).addBox(-2F, -4F, -5F, 4F, 4F, 6F), PartPose.offsetAndRotation(0F, -5F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_a_antler_r = p_a_head.addOrReplaceChild("a_antler_r", CubeListBuilder.create().texOffs(32, 67).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F), PartPose.offsetAndRotation(-1.5F, -4F, 2F, 0F, 0F, 0.35F));
        PartDefinition p_a_antler_l = p_a_head.addOrReplaceChild("a_antler_l", CubeListBuilder.create().texOffs(32, 67).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F), PartPose.offsetAndRotation(1.5F, -4F, 2F, 0F, 0F, -0.35F));
        PartDefinition p_a_nose = p_a_head.addOrReplaceChild("a_nose", CubeListBuilder.create().texOffs(36, 67).addBox(-1F, -2F, -6F, 2F, 2F, 1F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_a_leg_fl = root.addOrReplaceChild("a_leg_fl", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(2F, 17F, -20F, 0F, 0F, 0F));
        PartDefinition p_a_leg_fr = root.addOrReplaceChild("a_leg_fr", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(-2F, 17F, -20F, 0F, 0F, 0F));
        PartDefinition p_a_leg_bl = root.addOrReplaceChild("a_leg_bl", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(2F, 17F, -12F, 0F, 0F, 0F));
        PartDefinition p_a_leg_br = root.addOrReplaceChild("a_leg_br", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(-2F, 17F, -12F, 0F, 0F, 0F));
        PartDefinition p_b_body = root.addOrReplaceChild("b_body", CubeListBuilder.create().texOffs(86, 49).addBox(-3F, -3F, -6F, 6F, 6F, 12F), PartPose.offsetAndRotation(0F, 14F, -32F, 0F, 0F, 0F));
        PartDefinition p_b_neck = root.addOrReplaceChild("b_neck", CubeListBuilder.create().texOffs(0, 67).addBox(-1.5F, -5F, -1.5F, 3F, 5F, 3F), PartPose.offsetAndRotation(0F, 12F, -38F, -0.5F, 0F, 0F));
        PartDefinition p_b_head = p_b_neck.addOrReplaceChild("b_head", CubeListBuilder.create().texOffs(12, 67).addBox(-2F, -4F, -5F, 4F, 4F, 6F), PartPose.offsetAndRotation(0F, -5F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_b_antler_r = p_b_head.addOrReplaceChild("b_antler_r", CubeListBuilder.create().texOffs(32, 67).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F), PartPose.offsetAndRotation(-1.5F, -4F, 2F, 0F, 0F, 0.35F));
        PartDefinition p_b_antler_l = p_b_head.addOrReplaceChild("b_antler_l", CubeListBuilder.create().texOffs(32, 67).addBox(-0.5F, -6F, -0.5F, 1F, 6F, 1F), PartPose.offsetAndRotation(1.5F, -4F, 2F, 0F, 0F, -0.35F));
        PartDefinition p_b_nose = p_b_head.addOrReplaceChild("b_nose", CubeListBuilder.create().texOffs(36, 67).addBox(-1F, -2F, -6F, 2F, 2F, 1F), PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition p_b_leg_fl = root.addOrReplaceChild("b_leg_fl", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(2F, 17F, -36F, 0F, 0F, 0F));
        PartDefinition p_b_leg_fr = root.addOrReplaceChild("b_leg_fr", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(-2F, 17F, -36F, 0F, 0F, 0F));
        PartDefinition p_b_leg_bl = root.addOrReplaceChild("b_leg_bl", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(2F, 17F, -28F, 0F, 0F, 0F));
        PartDefinition p_b_leg_br = root.addOrReplaceChild("b_leg_br", CubeListBuilder.create().texOffs(42, 67).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(-2F, 17F, -28F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root.y = Mth.sin(ageInTicks * 0.15F) * 1.0F;
        this.root.xRot = Mth.sin(ageInTicks * 0.1F) * 0.02F;
        this.sack.xRot = Mth.sin(ageInTicks * 0.3F) * 0.03F;
        for (int i = 0; i < 2; i++) {
            float t = ageInTicks * 0.5F + i * 1.2F;
            ModelPart[] legs = i == 0
                    ? new ModelPart[]{this.a_leg_fl, this.a_leg_fr, this.a_leg_bl, this.a_leg_br}
                    : new ModelPart[]{this.b_leg_fl, this.b_leg_fr, this.b_leg_bl, this.b_leg_br};
            legs[0].xRot = Mth.sin(t) * 0.7F;
            legs[1].xRot = Mth.sin(t + Mth.PI) * 0.7F;
            legs[2].xRot = Mth.sin(t + Mth.PI) * 0.7F;
            legs[3].xRot = Mth.sin(t) * 0.7F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
