package com.treasurerainbow.entity;

import com.treasurerainbow.ModRegistry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/** Flecha de corazón de Cupido: no hace daño, cura a quien alcanza. */
public class HeartArrowEntity extends AbstractArrow {
    public HeartArrowEntity(EntityType<? extends HeartArrowEntity> type, Level level) {
        super(type, level);
        this.pickup = AbstractArrow.Pickup.DISALLOWED;
    }

    public HeartArrowEntity(Level level, LivingEntity owner) {
        super(ModRegistry.HEART_ARROW.get(), owner, level);
        this.pickup = AbstractArrow.Pickup.DISALLOWED;
    }

    @Override
    protected ItemStack getPickupItem() {
        return ItemStack.EMPTY;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.random.nextInt(2) == 0) {
                this.level().addParticle(ParticleTypes.HEART, this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D);
            }
        } else if (this.tickCount > 100) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        if (!this.level().isClientSide && target instanceof LivingEntity living && target != this.getOwner()) {
            living.heal(8.0F);
            living.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.HEART, living.getX(), living.getY() + living.getBbHeight() + 0.2D,
                        living.getZ(), 8, 0.3D, 0.3D, 0.3D, 0.05D);
                serverLevel.playSound(null, living.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 1.8F);
            }
        }
        if (!this.level().isClientSide) {
            this.discard();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (!this.level().isClientSide) {
            this.discard();
        }
    }
}
