package com.treasurerainbow.entity;

import com.treasurerainbow.world.FestiveFireworks;
import com.treasurerainbow.world.SaintJohnNight;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * El Pájaro Loco: un pájaro de correfoc enorme que escupe chispas y se ilumina a sí mismo
 * lanzando cohetes amarillos que suben al cielo y explotan. Aparece la Noche de San Juan
 * (y se va al amanecer). No ataca: solo hace el loco.
 */
public class CrazyBirdEntity extends PathfinderMob {
    private int fireworkCooldown = 40;
    private boolean eventBound;

    public CrazyBirdEntity(EntityType<? extends CrazyBirdEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setGlowingTag(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    /** Si es true, se esfuma al amanecer (los de la Noche de San Juan); el del huevo se queda. */
    public void setEventBound(boolean eventBound) {
        this.eventBound = eventBound;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.7D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.25D, 0.06F));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        Vec3 look = Vec3.directionFromRotation(0.0F, this.yBodyRot);
        if (this.level().isClientSide) {
            // chispas saliendo del pico
            double bx = this.getX() + look.x * 1.9D;
            double by = this.getY() + 2.4D;
            double bz = this.getZ() + look.z * 1.9D;
            for (int i = 0; i < 3; i++) {
                this.level().addParticle(ParticleTypes.FLAME, bx, by, bz,
                        look.x * 0.12D + (this.random.nextDouble() - 0.5D) * 0.08D,
                        (this.random.nextDouble() - 0.4D) * 0.12D,
                        look.z * 0.12D + (this.random.nextDouble() - 0.5D) * 0.08D);
            }
            this.level().addParticle(new DustParticleOptions(new Vector3f(1.0F, 0.85F, 0.1F), 1.0F), bx, by, bz,
                    look.x * 0.1D, 0.0D, look.z * 0.1D);
            if (this.random.nextInt(3) == 0) {
                this.level().addParticle(ParticleTypes.LAVA, bx, by, bz, 0.0D, 0.0D, 0.0D);
            }
            return;
        }
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        if (this.eventBound && this.tickCount % 20 == 0 && !SaintJohnNight.isActive(serverLevel)) {
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.5D, this.getZ(),
                    25, 0.6D, 0.8D, 0.6D, 0.03D);
            this.discard();
            return;
        }
        if (--this.fireworkCooldown <= 0) {
            this.fireworkCooldown = 50 + this.random.nextInt(60);
            FestiveFireworks.launch(serverLevel, this.getX() + look.x * 0.5D, this.getY() + 3.2D, this.getZ() + look.z * 0.5D,
                    this.random, FestiveFireworks.YELLOWS, 1 + this.random.nextInt(2));
            serverLevel.playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.NEUTRAL, 1.2F, 1.0F);
        }
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getAmbientSound() {
        return SoundEvents.CHICKEN_AMBIENT;
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.CHICKEN_HURT;
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getDeathSound() {
        return SoundEvents.CHICKEN_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 1.4F;
    }

    @Override
    public float getVoicePitch() {
        return 0.6F + this.random.nextFloat() * 0.2F;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("EventBound", this.eventBound);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.eventBound = tag.getBoolean("EventBound");
    }
}
