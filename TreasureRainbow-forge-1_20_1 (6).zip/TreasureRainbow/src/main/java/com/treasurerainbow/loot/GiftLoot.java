package com.treasurerainbow.loot;

import com.treasurerainbow.ModRegistry;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Contenido de los regalos mágicos: objetos variados + objetos al azar de los mods instalados. */
public final class GiftLoot {
    private GiftLoot() {}

    private record Entry(int weight, Supplier<ItemStack> stack) {}

    private static ItemStack range(RandomSource r, net.minecraft.world.item.Item item, int lo, int hi) {
        return new ItemStack(item, lo + r.nextInt(hi - lo + 1));
    }

    private static List<Entry> entries(RandomSource r) {
        List<Entry> list = new ArrayList<>();
        list.add(new Entry(10, () -> range(r, Items.COOKIE, 8, 16)));
        list.add(new Entry(4, () -> new ItemStack(Items.CAKE)));
        list.add(new Entry(6, () -> range(r, Items.PUMPKIN_PIE, 3, 6)));
        list.add(new Entry(6, () -> range(r, Items.COCOA_BEANS, 6, 12)));
        list.add(new Entry(5, () -> range(r, Items.SUGAR, 8, 16)));
        list.add(new Entry(10, () -> range(r, Items.GOLD_INGOT, 4, 12)));
        list.add(new Entry(8, () -> range(r, Items.EMERALD, 4, 10)));
        list.add(new Entry(5, () -> range(r, Items.DIAMOND, 1, 3)));
        list.add(new Entry(8, () -> range(r, Items.FIREWORK_ROCKET, 8, 16)));
        list.add(new Entry(5, () -> range(r, Items.SNOWBALL, 8, 16)));
        list.add(new Entry(8, () -> range(r, Items.EXPERIENCE_BOTTLE, 4, 10)));
        list.add(new Entry(5, () -> range(r, Items.GOLDEN_APPLE, 1, 3)));
        list.add(new Entry(4, () -> range(r, Items.SPRUCE_SAPLING, 2, 4)));
        list.add(new Entry(2, () -> new ItemStack(Items.MUSIC_DISC_CAT)));
        list.add(new Entry(1, () -> new ItemStack(Items.ENCHANTED_GOLDEN_APPLE)));
        list.add(new Entry(6, () -> range(r, Items.COOKED_BEEF, 6, 12)));
        list.add(new Entry(3, () -> range(r, Items.COAL, 4, 8)));
        list.add(new Entry(6, () -> new ItemStack(ModRegistry.RAINBOW_DUST.get(), 2 + r.nextInt(5))));
        list.add(new Entry(2, () -> new ItemStack(ModRegistry.RAINBOW_GEM.get())));
        list.add(new Entry(5, () -> new ItemStack(ModRegistry.FOUR_LEAF_CLOVER_ITEM.get(), 2 + r.nextInt(4))));
        list.add(new Entry(3, () -> new ItemStack(Items.NAME_TAG)));
        list.add(new Entry(2, () -> new ItemStack(Items.SADDLE)));
        list.add(new Entry(5, () -> range(r, Items.GOLDEN_CARROT, 6, 12)));
        list.add(new Entry(1, () -> new ItemStack(Items.TOTEM_OF_UNDYING)));
        list.add(new Entry(3, () -> range(r, Items.ENDER_PEARL, 2, 5)));
        return list;
    }

    /** Tira el contenido de un regalo. */
    public static List<ItemStack> roll(RandomSource random) {
        List<Entry> entries = entries(random);
        int total = 0;
        for (Entry e : entries) {
            total += e.weight();
        }
        List<ItemStack> out = new ArrayList<>();
        int count = 5 + random.nextInt(4);
        for (int i = 0; i < count; i++) {
            int pick = random.nextInt(total);
            for (Entry e : entries) {
                pick -= e.weight();
                if (pick < 0) {
                    out.add(e.stack().get());
                    break;
                }
            }
        }
        // Objetos al azar de los mods instalados
        int modded = 2 + random.nextInt(3);
        for (int i = 0; i < modded; i++) {
            ItemStack stack = LegendaryLoot.randomModded(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        // Algo valioso (de vanilla o de cualquier mod)
        int valuable = 1 + (random.nextFloat() < 0.4F ? 1 : 0);
        for (int i = 0; i < valuable; i++) {
            ItemStack stack = LegendaryLoot.randomValuable(random);
            if (!stack.isEmpty()) {
                out.add(stack);
            }
        }
        return out;
    }
}
