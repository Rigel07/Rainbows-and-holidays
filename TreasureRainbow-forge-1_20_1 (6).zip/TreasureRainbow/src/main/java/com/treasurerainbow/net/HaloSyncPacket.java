package com.treasurerainbow.net;

import com.treasurerainbow.halo.ClientHaloCache;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: este jugador lleva (o ya no lleva) este halo. */
public class HaloSyncPacket {
    private final int entityId;
    private final ItemStack stack;

    public HaloSyncPacket(int entityId, ItemStack stack) {
        this.entityId = entityId;
        this.stack = stack;
    }

    public static void encode(HaloSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeItem(msg.stack);
    }

    public static HaloSyncPacket decode(FriendlyByteBuf buf) {
        return new HaloSyncPacket(buf.readVarInt(), buf.readItem());
    }

    public static void handle(HaloSyncPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> ClientHaloCache.set(msg.entityId, msg.stack));
        context.setPacketHandled(true);
    }
}
