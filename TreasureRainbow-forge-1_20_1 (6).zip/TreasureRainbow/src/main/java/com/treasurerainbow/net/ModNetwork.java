package com.treasurerainbow.net;

import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.halo.HaloData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private ModNetwork() {}

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TreasureRainbowMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, HaloClickPacket.class, HaloClickPacket::encode, HaloClickPacket::decode, HaloClickPacket::handle);
        CHANNEL.registerMessage(id++, HaloSyncPacket.class, HaloSyncPacket::encode, HaloSyncPacket::decode, HaloSyncPacket::handle);
    }

    /** Envía el halo de {@code owner} a él mismo y a quienes lo están viendo. */
    public static void syncHalo(ServerPlayer owner) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> owner),
                new HaloSyncPacket(owner.getId(), HaloData.get(owner)));
    }

    /** Envía el halo de {@code owner} solo a {@code receiver}. */
    public static void sendTo(ServerPlayer receiver, ServerPlayer owner) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> receiver),
                new HaloSyncPacket(owner.getId(), HaloData.get(owner)));
    }
}
