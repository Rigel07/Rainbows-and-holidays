package com.treasurerainbow.halo;

import com.treasurerainbow.item.AngelHaloItem;
import com.treasurerainbow.net.ModNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** El hueco del halo de cada jugador (guardado en sus datos persistentes; solo se usa en el servidor). */
public final class HaloData {
    private HaloData() {}

    public static final String KEY = "treasure_rainbow_halo";

    public static ItemStack get(Player player) {
        CompoundTag data = player.getPersistentData();
        return data.contains(KEY) ? ItemStack.of(data.getCompound(KEY)) : ItemStack.EMPTY;
    }

    public static boolean has(Player player) {
        return get(player).getItem() instanceof AngelHaloItem;
    }

    public static void set(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) {
            player.getPersistentData().remove(KEY);
        } else {
            player.getPersistentData().put(KEY, stack.save(new CompoundTag()));
        }
        ModNetwork.syncHalo(player);
    }
}
