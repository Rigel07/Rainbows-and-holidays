package com.treasurerainbow.halo;

import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.item.AngelHaloItem;
import com.treasurerainbow.net.ModNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/** Efectos del Halo Angelical y mantenimiento de su hueco (sincronización, muerte, respawn). */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class HaloEvents {
    private HaloEvents() {}

    private static final UUID HEALTH_ID = UUID.fromString("5f0c7d86-3a52-4b1e-9d46-0c5ae7b1f001");

    /** Clic en el hueco del halo (llega desde el cliente): intercambia el objeto del cursor con el halo. */
    public static void handleClick(ServerPlayer player) {
        AbstractContainerMenu menu = player.containerMenu;
        ItemStack carried = menu.getCarried();
        ItemStack current = HaloData.get(player);
        if (carried.isEmpty() && current.isEmpty()) {
            return;
        }
        if (!carried.isEmpty() && !(carried.getItem() instanceof AngelHaloItem)) {
            return;
        }
        ItemStack newHalo = carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1);
        ItemStack rest = carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(carried.getCount() - 1);
        ItemStack newCarried = current.isEmpty() ? rest : current;
        if (!current.isEmpty() && !rest.isEmpty()) {
            // el cursor tenía varios halos: el halo que estaba puesto va al inventario
            if (!player.getInventory().add(current.copy())) {
                player.drop(current.copy(), false);
            }
            newCarried = rest;
        }
        HaloData.set(player, newHalo);
        menu.setCarried(newCarried);
        menu.sendAllDataToRemote();
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player) || player.tickCount % 10 != 0) {
            return;
        }
        boolean has = HaloData.has(player);
        AttributeInstance health = player.getAttribute(Attributes.MAX_HEALTH);
        if (health != null) {
            boolean applied = health.getModifier(HEALTH_ID) != null;
            if (has && !applied) {
                health.addPermanentModifier(new AttributeModifier(HEALTH_ID, "Angelic halo", 10.0D, AttributeModifier.Operation.ADDITION));
                player.heal(10.0F);
            } else if (!has && applied) {
                health.removeModifier(HEALTH_ID);
                if (player.getHealth() > player.getMaxHealth()) {
                    player.setHealth(player.getMaxHealth());
                }
            }
        }
        if (has) {
            MobEffectInstance current = player.getEffect(MobEffects.WATER_BREATHING);
            if (current == null || current.getDuration() < 100) {
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 240, 0, false, false, false));
            }
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && HaloData.has(player)) {
            event.setDamageMultiplier(0.0F);
        }
    }

    /** Quien ataca al portador del halo se envenena y se debilita automáticamente. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof ServerPlayer victim && HaloData.has(victim)
                && event.getSource().getEntity() instanceof LivingEntity attacker && attacker != victim) {
            attacker.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 0));
            attacker.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
        }
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && !player.level().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) {
            ItemStack halo = HaloData.get(player);
            if (!halo.isEmpty()) {
                event.getDrops().add(new ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), halo));
                player.getPersistentData().remove(HaloData.KEY);
            }
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag old = event.getOriginal().getPersistentData();
        if (old.contains(HaloData.KEY)) {
            event.getEntity().getPersistentData().put(HaloData.KEY, old.getCompound(HaloData.KEY));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ModNetwork.syncHalo(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ModNetwork.syncHalo(player);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ModNetwork.syncHalo(player);
        }
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer owner && event.getEntity() instanceof ServerPlayer receiver) {
            ModNetwork.sendTo(receiver, owner);
        }
    }
}
