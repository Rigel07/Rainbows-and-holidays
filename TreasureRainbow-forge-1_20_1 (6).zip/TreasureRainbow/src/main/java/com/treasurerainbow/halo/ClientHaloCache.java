package com.treasurerainbow.halo;

import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;

/** Lo que el cliente sabe de los halos equipados (por id de entidad del jugador). */
public final class ClientHaloCache {
    private ClientHaloCache() {}

    private static final Map<Integer, ItemStack> HALOS = new HashMap<>();

    public static void set(int entityId, ItemStack stack) {
        if (stack.isEmpty()) {
            HALOS.remove(entityId);
        } else {
            HALOS.put(entityId, stack);
        }
    }

    public static ItemStack get(int entityId) {
        return HALOS.getOrDefault(entityId, ItemStack.EMPTY);
    }
}
