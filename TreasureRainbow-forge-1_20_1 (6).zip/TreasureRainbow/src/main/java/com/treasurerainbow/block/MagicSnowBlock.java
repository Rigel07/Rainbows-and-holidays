package com.treasurerainbow.block;

import com.treasurerainbow.world.ChristmasEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Nieve mágica de Navidad: cae en cualquier bioma y se derrite sola cuando acaba el evento. */
public class MagicSnowBlock extends SnowLayerBlock {
    public MagicSnowBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, 100);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!ChristmasEvent.isActive(level)) {
            level.removeBlock(pos, false);
        } else {
            level.scheduleTick(pos, this, 200);
        }
    }
}
