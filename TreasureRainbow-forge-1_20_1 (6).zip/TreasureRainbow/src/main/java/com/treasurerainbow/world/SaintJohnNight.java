package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.block.SanJuanBonfireBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * La Noche de San Juan (solsticio de verano): se celebra cada 2 días del mundo (al caer la noche)
 * y dura hasta el amanecer. Durante la noche:
 * <ul>
 *   <li>aparecen hogueras por el mundo (con cohetes); se apagan al amanecer;</li>
 *   <li>fertilidad: los cultivos y los árboles jóvenes crecen y los animales entran en celo;</li>
 *   <li>culto solar: el fuego quema a los no-muertos que se acercan;</li>
 *   <li>los jugadores reciben la Bendición del Solsticio (salto aumentado, para saltar las hogueras).</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class SaintJohnNight {
    private SaintJohnNight() {}

    /** Cada cuántos días del mundo se celebra (el día 2, 4, 6...). */
    public static final int INTERVAL_DAYS = 2;
    /** Hora del día en la que cae la noche y empieza la celebración. */
    private static final long NIGHTFALL = 13000L;
    private static final int EFFECT_TICKS = 240;
    /** Probabilidad por segundo y jugador de encender una hoguera nueva cerca. */
    private static final double BONFIRE_CHANCE = 0.08D;

    private static final Map<UUID, BlockPos> LAST_BONFIRE = new HashMap<>();

    public static boolean isActive(MinecraftServer server) {
        return server != null && SaintJohnData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    /** Día del mundo en el que empezó la noche en curso (identifica la celebración). */
    public static long currentStartDay(ServerLevel level) {
        return SaintJohnData.get(level.getServer().overworld()).startDay;
    }

    // ----------------------------------------------------------- Empezar / parar

    public static boolean start(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        SaintJohnData data = SaintJohnData.get(overworld);
        if (data.active) {
            return false;
        }
        long day = overworld.getDayTime() / 24000L;
        data.active = true;
        data.startDay = day;
        data.lastStartedDay = day;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.sanjuan_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.sanjuan_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.sanjuan_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        SaintJohnData data = SaintJohnData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        LAST_BONFIRE.clear();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            removeOurs(player, ModRegistry.SOLSTICE_BLESSING.get());
            removeOurs(player, MobEffects.JUMP);
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.sanjuan_end"), false);
        return true;
    }

    // ------------------------------------------------------------------ Eventos

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        SaintJohnData data = SaintJohnData.get(overworld);
        long dayTime = overworld.getDayTime();
        long day = dayTime / 24000L;
        long timeOfDay = dayTime % 24000L;

        if (data.active) {
            if (day != data.startDay) {
                stop(server);
                return;
            }
        } else if (day % INTERVAL_DAYS == INTERVAL_DAYS - 1 && timeOfDay >= NIGHTFALL && data.lastStartedDay != day) {
            start(server);
        }

        if (data.active) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.isSpectator() || !player.isAlive()) {
                    continue;
                }
                refresh(player, ModRegistry.SOLSTICE_BLESSING.get(), 0, true);
                refresh(player, MobEffects.JUMP, 1, false);
                if (player.level() instanceof ServerLevel level) {
                    fertility(level, player);
                    maybeLightBonfire(level, player);
                    maybeSpawnCrazyBird(level, player);
                    groundFireworks(level, player);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Ayudas

    private static void refresh(ServerPlayer player, MobEffect effect, int amplifier, boolean showIcon) {
        MobEffectInstance current = player.getEffect(effect);
        if (current == null || current.getDuration() < 100) {
            player.addEffect(new MobEffectInstance(effect, EFFECT_TICKS, amplifier, false, false, showIcon));
        }
    }

    private static void removeOurs(ServerPlayer player, MobEffect effect) {
        MobEffectInstance current = player.getEffect(effect);
        if (current != null && current.getDuration() <= EFFECT_TICKS) {
            player.removeEffect(effect);
        }
    }

    /** Fertilidad: hace crecer cultivos y árboles jóvenes cerca y pone en celo a los animales. */
    private static void fertility(ServerLevel level, ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        for (int i = 0; i < 4; i++) {
            BlockPos p = origin.offset(level.random.nextInt(21) - 10, level.random.nextInt(5) - 2, level.random.nextInt(21) - 10);
            BlockState state = level.getBlockState(p);
            if (state.is(BlockTags.CROPS) || state.is(BlockTags.SAPLINGS)) {
                BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), level, p, player);
            }
        }
        for (Animal animal : level.getEntitiesOfClass(Animal.class, player.getBoundingBox().inflate(12.0D))) {
            if (animal.getAge() == 0 && !animal.isInLove() && level.random.nextDouble() < 0.04D) {
                animal.setInLove(null);
            }
        }
    }

    /** El suelo se llena de fuegos artificiales: surtidores de chispas y cohetes que salen de la tierra. */
    private static void groundFireworks(ServerLevel level, ServerPlayer player) {
        for (int i = 0; i < 5; i++) {
            int x = player.getBlockX() + level.random.nextInt(57) - 28;
            int z = player.getBlockZ() + level.random.nextInt(57) - 28;
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (!level.getFluidState(new BlockPos(x, y - 1, z)).isEmpty()) {
                continue;
            }
            level.sendParticles(ParticleTypes.FIREWORK, x + 0.5D, y + 0.1D, z + 0.5D, 14, 0.25D, 0.05D, 0.25D, 0.15D);
            level.sendParticles(ParticleTypes.FLAME, x + 0.5D, y + 0.1D, z + 0.5D, 4, 0.2D, 0.05D, 0.2D, 0.04D);
            if (level.random.nextInt(2) == 0) {
                FestiveFireworks.launch(level, x + 0.5D, y + 0.2D, z + 0.5D, level.random, FestiveFireworks.MULTI, 1);
            }
        }
    }

    /** El Pájaro Loco aparece suelto cerca de los jugadores (solo uno a la vez por zona). */
    private static void maybeSpawnCrazyBird(ServerLevel level, ServerPlayer player) {
        if (level.dimension() != net.minecraft.world.level.Level.OVERWORLD || level.random.nextDouble() > 0.04D
                || !level.getEntitiesOfClass(com.treasurerainbow.entity.CrazyBirdEntity.class, player.getBoundingBox().inflate(96.0D)).isEmpty()) {
            return;
        }
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = 24.0D + level.random.nextInt(16);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            com.treasurerainbow.entity.CrazyBirdEntity bird = ModRegistry.CRAZY_BIRD.get().create(level);
            if (bird == null) {
                return;
            }
            bird.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            bird.setEventBound(true);
            level.addFreshEntity(bird);
            player.displayClientMessage(Component.translatable("message.treasure_rainbow.crazy_bird_appeared"), true);
            return;
        }
    }

    /** Enciende una hoguera "natural" cerca del jugador si no tiene ya una cerca. */
    private static void maybeLightBonfire(ServerLevel level, ServerPlayer player) {
        if (level.random.nextDouble() > BONFIRE_CHANCE) {
            return;
        }
        BlockPos last = LAST_BONFIRE.get(player.getUUID());
        if (last != null && level.getBlockState(last).is(ModRegistry.SAN_JUAN_BONFIRE.get())
                && last.distSqr(player.blockPosition()) < 60.0D * 60.0D) {
            return;
        }
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = 20.0D + level.random.nextInt(20);
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            BlockPos below = pos.below();
            if (level.getBlockState(pos).canBeReplaced() && level.getFluidState(pos).isEmpty()
                    && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                    && level.getBlockState(below).getFluidState().isEmpty()) {
                level.setBlock(pos, ModRegistry.SAN_JUAN_BONFIRE.get().defaultBlockState()
                        .setValue(SanJuanBonfireBlock.NATURAL, true), 3);
                LAST_BONFIRE.put(player.getUUID(), pos);
                return;
            }
        }
    }
}
