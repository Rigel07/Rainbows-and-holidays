package com.treasurerainbow.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado guardado del evento de Navidad (vive en el Overworld). */
public class ChristmasData extends SavedData {
    private static final String NAME = "treasure_rainbow_christmas";
    public boolean active;
    public long lastDay = -1L;

    public static ChristmasData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(ChristmasData::load, ChristmasData::new, NAME);
    }

    public static ChristmasData load(CompoundTag tag) {
        ChristmasData data = new ChristmasData();
        data.active = tag.getBoolean("Active");
        data.lastDay = tag.contains("LastDay") ? tag.getLong("LastDay") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Active", this.active);
        tag.putLong("LastDay", this.lastDay);
        return tag;
    }
}
