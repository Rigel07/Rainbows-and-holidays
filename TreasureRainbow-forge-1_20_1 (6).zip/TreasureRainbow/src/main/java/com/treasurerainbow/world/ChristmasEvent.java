package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.block.MagicSnowBlock;
import com.treasurerainbow.entity.ElfEntity;
import com.treasurerainbow.entity.SleighEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.time.LocalDate;

/**
 * La Navidad: empieza de golpe al amanecer (probabilidad pequeña; segura del 24 al 26 de diciembre reales)
 * y dura hasta el siguiente amanecer.
 * <ul>
 *   <li>Nieva en todo el mundo, sea cual sea el bioma (nieve mágica que se derrite al acabar + copos en pantalla);</li>
 *   <li>aparecen elfos de golpe (hablando con ellos dan un regalo);</li>
 *   <li>un trineo mágico cruza el cielo soltando regalos mágicos.</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class ChristmasEvent {
    private ChristmasEvent() {}

    public static final double START_CHANCE = 0.10D;
    private static final int EFFECT_TICKS = 240;
    private static int sleighTimer;

    public static boolean isActive(MinecraftServer server) {
        return server != null && ChristmasData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    // ----------------------------------------------------------- Empezar / parar

    public static boolean start(MinecraftServer server) {
        ChristmasData data = ChristmasData.get(server.overworld());
        if (data.active) {
            return false;
        }
        data.active = true;
        data.setDirty();
        sleighTimer = 100;
        Component title = Component.translatable("message.treasure_rainbow.christmas_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.christmas_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.5F);
            if (player.level() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
                for (int i = 0; i < 4; i++) {
                    spawnElf(level, player, 8, 22);   // ¡de golpe!
                }
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.christmas_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        ChristmasData data = ChristmasData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            MobEffectInstance current = player.getEffect(ModRegistry.CHRISTMAS_SPIRIT.get());
            if (current != null && current.getDuration() <= EFFECT_TICKS) {
                player.removeEffect(ModRegistry.CHRISTMAS_SPIRIT.get());
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.christmas_end"), false);
        return true;
    }

    // ------------------------------------------------------------------ Tick

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        ServerLevel overworld = server.overworld();
        ChristmasData data = ChristmasData.get(overworld);
        if (data.active && server.getTickCount() % 4 == 0) {
            snow(overworld);
        }
        if (server.getTickCount() % 20 != 0) {
            return;
        }
        long day = overworld.getDayTime() / 24000L;
        if (data.lastDay < 0L) {
            data.lastDay = day;
            data.setDirty();
        } else if (day != data.lastDay) {
            data.lastDay = day;
            data.setDirty();
            if (data.active) {
                stop(server);
            } else if (overworld.random.nextDouble() < startChance()) {
                start(server);
            }
        }
        if (!data.active) {
            return;
        }
        for (ServerPlayer player : overworld.players()) {
            if (player.isSpectator()) {
                continue;
            }
            MobEffectInstance current = player.getEffect(ModRegistry.CHRISTMAS_SPIRIT.get());
            if (current == null || current.getDuration() < 100) {
                player.addEffect(new MobEffectInstance(ModRegistry.CHRISTMAS_SPIRIT.get(), EFFECT_TICKS, 0, false, false, true));
            }
            if (overworld.getEntitiesOfClass(ElfEntity.class, player.getBoundingBox().inflate(48.0D)).size() < 5
                    && overworld.random.nextDouble() < 0.15D) {
                spawnElf(overworld, player, 14, 30);
            }
        }
        sleighTimer -= 20;
        if (sleighTimer <= 0 && !overworld.players().isEmpty()) {
            ServerPlayer target = overworld.players().get(overworld.random.nextInt(overworld.players().size()));
            if (spawnSleigh(overworld, target)) {
                sleighTimer = 2400 + overworld.random.nextInt(2400);
            } else {
                sleighTimer = 200;
            }
        }
    }

    private static double startChance() {
        LocalDate today = LocalDate.now();
        boolean realChristmas = today.getMonthValue() == 12 && today.getDayOfMonth() >= 24 && today.getDayOfMonth() <= 26;
        return realChristmas ? 1.0D : START_CHANCE;
    }

    // ------------------------------------------------------------------ Nieve

    /** Cubre de nieve mágica los alrededores de cada jugador, sin importar el bioma. */
    private static void snow(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            BlockPos origin = player.blockPosition();
            for (int i = 0; i < 3; i++) {
                int x = origin.getX() + level.random.nextInt(57) - 28;
                int z = origin.getZ() + level.random.nextInt(57) - 28;
                if (!level.hasChunk(x >> 4, z >> 4)) {
                    continue;
                }
                BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z);
                BlockState state = level.getBlockState(pos);
                Block snow = ModRegistry.MAGIC_SNOW.get();
                if (state.is(snow)) {
                    int layers = state.getValue(SnowLayerBlock.LAYERS);
                    if (layers < 3) {
                        level.setBlock(pos, state.setValue(SnowLayerBlock.LAYERS, layers + 1), 2);
                    }
                } else if ((state.isAir() || state.canBeReplaced()) && level.getFluidState(pos).isEmpty()) {
                    BlockState snowState = snow.defaultBlockState();
                    if (snowState.canSurvive(level, pos)) {
                        level.setBlock(pos, snowState, 2);
                    }
                }
            }
        }
    }

    // ----------------------------------------------------------- Elfos y trineo

    public static boolean spawnElf(ServerLevel level, ServerPlayer player, int minDist, int maxDist) {
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = minDist + level.random.nextInt(Math.max(1, maxDist - minDist));
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            ElfEntity elf = ModRegistry.ELF.get().create(level);
            if (elf == null) {
                return false;
            }
            elf.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            elf.setEventBound(true);
            level.addFreshEntity(elf);
            level.sendParticles(ParticleTypes.SNOWFLAKE, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    25, 0.3D, 0.6D, 0.3D, 0.08D);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    10, 0.3D, 0.5D, 0.3D, 0.05D);
            return true;
        }
        return false;
    }

    /** Un trineo mágico entra por el horizonte y cruza el cielo por encima del jugador. */
    public static boolean spawnSleigh(ServerLevel level, ServerPlayer player) {
        if (level.dimension() != Level.OVERWORLD) {
            return false;
        }
        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        double sx = player.getX() + Math.cos(angle) * 80.0D;
        double sz = player.getZ() + Math.sin(angle) * 80.0D;
        double sy = Mth.clamp(player.getY() + 48.0D, level.getMinBuildHeight() + 10, level.getMaxBuildHeight() - 12);
        if (!level.hasChunk(Mth.floor(sx) >> 4, Mth.floor(sz) >> 4)) {
            return false;
        }
        double dx = player.getX() - sx;
        double dz = player.getZ() - sz;
        float yaw = (float) (Mth.atan2(-dx, dz) * 180.0D / Math.PI);
        SleighEntity sleigh = ModRegistry.SLEIGH.get().create(level);
        if (sleigh == null) {
            return false;
        }
        sleigh.moveTo(sx, sy, sz, yaw, 0.0F);
        level.addFreshEntity(sleigh);
        for (ServerPlayer p : level.players()) {
            p.displayClientMessage(Component.translatable("message.treasure_rainbow.sleigh_passing"), true);
        }
        return true;
    }
}
