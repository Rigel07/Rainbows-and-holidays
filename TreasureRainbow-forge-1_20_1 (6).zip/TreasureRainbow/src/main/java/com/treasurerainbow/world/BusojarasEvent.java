package com.treasurerainbow.world;

import com.treasurerainbow.ModRegistry;
import com.treasurerainbow.TreasureRainbowMod;
import com.treasurerainbow.entity.BusoEntity;
import com.treasurerainbow.item.BusoMaskItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * El Busójárás de Mohács (Hungría): carnaval en el que los busós, con máscaras de madera con cuernos, pieles
 * de oveja y cencerros, recorren el pueblo haciendo ruido para espantar al invierno y a los malos espíritus.
 * Empieza al amanecer (probabilidad pequeña) y dura hasta el siguiente amanecer.
 * <ul>
 *   <li>Aparecen busós que persiguen a los jugadores y espantan a los monstruos;</li>
 *   <li>con una Máscara de Busó puesta los busós te toman por uno de los suyos y los monstruos huyen de ti;</li>
 *   <li>en las hogueras se queman bolas de nieve para despedir al invierno.</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public final class BusojarasEvent {
    private BusojarasEvent() {}

    public static final double START_CHANCE = 0.08D;

    public static boolean isActive(MinecraftServer server) {
        return server != null && BusojarasData.get(server.overworld()).active;
    }

    public static boolean isActive(ServerLevel level) {
        return isActive(level.getServer());
    }

    public static boolean start(MinecraftServer server) {
        BusojarasData data = BusojarasData.get(server.overworld());
        if (data.active) {
            return false;
        }
        data.active = true;
        data.setDirty();
        Component title = Component.translatable("message.treasure_rainbow.busojaras_start.title");
        Component subtitle = Component.translatable("message.treasure_rainbow.busojaras_start.subtitle");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 30));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0F, 0.6F);
            if (player.level() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
                for (int i = 0; i < 4; i++) {
                    spawnBuso(level, player, 12, 26);
                }
            }
        }
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.busojaras_start.chat"), false);
        return true;
    }

    public static boolean stop(MinecraftServer server) {
        BusojarasData data = BusojarasData.get(server.overworld());
        if (!data.active) {
            return false;
        }
        data.active = false;
        data.setDirty();
        server.getPlayerList().broadcastSystemMessage(Component.translatable("message.treasure_rainbow.busojaras_end"), false);
        return true;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) {
            return;
        }
        ServerLevel overworld = server.overworld();
        BusojarasData data = BusojarasData.get(overworld);
        long day = overworld.getDayTime() / 24000L;
        if (data.lastDay < 0L) {
            data.lastDay = day;
            data.setDirty();
        } else if (day != data.lastDay) {
            data.lastDay = day;
            data.setDirty();
            if (data.active) {
                stop(server);
            } else if (overworld.random.nextDouble() < START_CHANCE) {
                start(server);
            }
        }
        // Con la máscara puesta (siempre) los monstruos cercanos huyen de ti.
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!player.isSpectator() && BusoMaskItem.isWearing(player) && player.level() instanceof ServerLevel level) {
                BusoEntity.scareMonsters(level, player.position(), 8.0D);
            }
        }
        if (!data.active) {
            return;
        }
        for (ServerPlayer player : overworld.players()) {
            if (player.isSpectator()) {
                continue;
            }
            if (overworld.getEntitiesOfClass(BusoEntity.class, player.getBoundingBox().inflate(64.0D)).size() < 4
                    && overworld.random.nextDouble() < 0.2D) {
                spawnBuso(overworld, player, 16, 32);
            }
        }
    }

    public static boolean spawnBuso(ServerLevel level, ServerPlayer player, int minDist, int maxDist) {
        BlockPos origin = player.blockPosition();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double distance = minDist + level.random.nextInt(Math.max(1, maxDist - minDist));
            int x = origin.getX() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.getZ() + (int) Math.round(Math.sin(angle) * distance);
            if (!level.hasChunk(x >> 4, z >> 4)) {
                continue;
            }
            BlockPos pos = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (!RainbowSpawner.isFreeSpot(level, pos)) {
                continue;
            }
            BusoEntity buso = ModRegistry.BUSO.get().create(level);
            if (buso == null) {
                return false;
            }
            buso.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            buso.setEventBound(true);
            level.addFreshEntity(buso);
            level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 20, 0.4D, 0.7D, 0.4D, 0.05D);
            return true;
        }
        return false;
    }
}
