package com.treasurerainbow.world;

import com.mojang.brigadier.context.CommandContext;
import com.treasurerainbow.TreasureRainbowMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TreasureRainbowMod.MOD_ID)
public class RainbowEvents {
    /** Cada cuántos ticks se "tira el dado" para crear un arcoíris (400 = 20 segundos). */
    private static final int CHECK_INTERVAL = 400;
    /** Probabilidad por jugador y comprobación en un día soleado. */
    private static final double BASE_CHANCE = 0.06D;
    /** Probabilidad justo después de que pare de llover (y durante el Día de San Patricio). */
    private static final double AFTER_RAIN_CHANCE = 0.40D;
    /** Cuánto dura ese "después de la lluvia" (ticks). */
    private static final int AFTER_RAIN_TICKS = 6000;
    /** Durante el Día de San Patricio: probabilidad por jugador y comprobación de que pasee un duende. */
    private static final double WANDERING_LEPRECHAUN_CHANCE = 0.03D;

    private static boolean wasRaining;
    private static int afterRain;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)
                || level.dimension() != Level.OVERWORLD) {
            return;
        }
        boolean raining = level.isRaining();
        if (wasRaining && !raining) {
            afterRain = AFTER_RAIN_TICKS;
        }
        wasRaining = raining;
        if (afterRain > 0) {
            afterRain--;
        }

        if (level.getGameTime() % CHECK_INTERVAL != 0 || raining || !level.isDay()) {
            return;
        }
        boolean saintDay = SaintPatrickDay.isActive(level);
        double chance = (afterRain > 0 || saintDay) ? AFTER_RAIN_CHANCE : BASE_CHANCE;
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) {
                continue;
            }
            if (level.random.nextDouble() <= chance) {
                RainbowSpawner.Result result = RainbowSpawner.trySpawnNear(level, player, false, RainbowSpawner.SPECIAL_AUTO);
                if (result != null) {
                    RainbowSpawner.announce(player, result.special());
                    continue;
                }
            }
            if (saintDay && level.random.nextDouble() < WANDERING_LEPRECHAUN_CHANCE) {
                RainbowSpawner.spawnWanderingLeprechaun(level, player);
            }
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        // /rainbow (solo operadores): crea un arcoíris cerca de ti para probar.
        // /rainbow leprechaun: el mismo, pero con caldero de oro, duende y cofre legendario.
        event.getDispatcher().register(Commands.literal("rainbow")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnTestRainbow(context, RainbowSpawner.SPECIAL_NEVER))
                .then(Commands.literal("leprechaun")
                        .executes(context -> spawnTestRainbow(context, RainbowSpawner.SPECIAL_ALWAYS))));

        registerSanJuan(event.getDispatcher());
        registerChristmasAndValentine(event.getDispatcher());
        registerBusojaras(event.getDispatcher());

        // /saintpatrick start | stop (solo operadores): empieza o termina el Día de San Patricio.
        event.getDispatcher().register(Commands.literal("saintpatrick")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("start").executes(context -> {
                    boolean started = SaintPatrickDay.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(started
                            ? "message.treasure_rainbow.saint_command_started"
                            : "message.treasure_rainbow.saint_command_already"), true);
                    return started ? 1 : 0;
                }))
                .then(Commands.literal("stop").executes(context -> {
                    boolean stopped = SaintPatrickDay.stop(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(stopped
                            ? "message.treasure_rainbow.saint_command_stopped"
                            : "message.treasure_rainbow.saint_command_not_active"), true);
                    return stopped ? 1 : 0;
                })));
    }

    private static void registerSanJuan(com.mojang.brigadier.CommandDispatcher<CommandSourceStack> dispatcher) {
        // /sanjuan start | stop (solo operadores): empieza o termina la Noche de San Juan.
        dispatcher.register(Commands.literal("sanjuan")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("start").executes(context -> {
                    boolean started = SaintJohnNight.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(started
                            ? "message.treasure_rainbow.sanjuan_command_started"
                            : "message.treasure_rainbow.sanjuan_command_already"), true);
                    return started ? 1 : 0;
                }))
                .then(Commands.literal("stop").executes(context -> {
                    boolean stopped = SaintJohnNight.stop(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(stopped
                            ? "message.treasure_rainbow.sanjuan_command_stopped"
                            : "message.treasure_rainbow.sanjuan_command_not_active"), true);
                    return stopped ? 1 : 0;
                })));
    }

    private static void registerChristmasAndValentine(com.mojang.brigadier.CommandDispatcher<CommandSourceStack> dispatcher) {
        // /christmas start | stop | sleigh
        dispatcher.register(Commands.literal("christmas")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("start").executes(context -> {
                    boolean ok = ChristmasEvent.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.christmas_command_started"
                            : "message.treasure_rainbow.christmas_command_already"), true);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("stop").executes(context -> {
                    boolean ok = ChristmasEvent.stop(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.christmas_command_stopped"
                            : "message.treasure_rainbow.christmas_command_not_active"), true);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("sleigh").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    boolean ok = player.level() instanceof ServerLevel level && ChristmasEvent.spawnSleigh(level, player);
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.sleigh_command_ok"
                            : "message.treasure_rainbow.sleigh_command_fail"), true);
                    return ok ? 1 : 0;
                })));
        // /valentine start | stop
        dispatcher.register(Commands.literal("valentine")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("start").executes(context -> {
                    boolean ok = ValentineEvent.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.valentine_command_started"
                            : "message.treasure_rainbow.valentine_command_already"), true);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("stop").executes(context -> {
                    boolean ok = ValentineEvent.stop(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.valentine_command_stopped"
                            : "message.treasure_rainbow.valentine_command_not_active"), true);
                    return ok ? 1 : 0;
                })));
    }

    private static void registerBusojaras(com.mojang.brigadier.CommandDispatcher<CommandSourceStack> dispatcher) {
        // /busojaras start | stop
        dispatcher.register(Commands.literal("busojaras")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("start").executes(context -> {
                    boolean ok = BusojarasEvent.start(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.busojaras_command_started"
                            : "message.treasure_rainbow.busojaras_command_already"), true);
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("stop").executes(context -> {
                    boolean ok = BusojarasEvent.stop(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.translatable(ok
                            ? "message.treasure_rainbow.busojaras_command_stopped"
                            : "message.treasure_rainbow.busojaras_command_not_active"), true);
                    return ok ? 1 : 0;
                })));
    }

    private static int spawnTestRainbow(CommandContext<CommandSourceStack> context, int specialMode) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = context.getSource().getPlayerOrException();
        RainbowSpawner.Result result = RainbowSpawner.trySpawnNear(context.getSource().getLevel(), player, true, specialMode);
        player.displayClientMessage(Component.translatable(result != null
                ? "message.treasure_rainbow.command_ok" : "message.treasure_rainbow.command_fail"), false);
        return result != null ? 1 : 0;
    }
}
